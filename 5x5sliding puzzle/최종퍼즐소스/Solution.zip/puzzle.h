#define SIZE 5
#define BLANK SIZE * SIZE
#define FALSE 0
#define TRUE !FALSE

/* return status */
typedef enum {
	ERROR = -1,
	SUCCESS = 1
} status;

/* moving direction */
typedef enum {
	LEFT,
	RIGHT,
	UP,
	DOWN
} direction;

/* blank position */
typedef struct {
	int row;
	int col;
} position;

/* function declaration */

int** initialize(int, char**);
int** get_status(void);
status move(direction);
position get_position(void);

char s[700];
int count = 0;


int _np[SIZE][SIZE] = { {0, }, };
int _trycount = 0;
position __pos;
int T;


int** get_status(void)
{
	int i, j;
	int** __np;

	__np = (int**)malloc(SIZE * sizeof(int*));
	__np[0] = (int*)malloc(SIZE * SIZE * sizeof(int*));

	for (i = 1; i < SIZE; i++)
		__np[i] = __np[0] + i * SIZE;

	for (i = 0; i < SIZE; i++)
		for (j = 0; j < SIZE; j++)
			__np[i][j] = _np[i][j];

	return (__np);
}

int** initialize(int, char**)
{
	int i = 0;

	int** __np;

	_trycount = 0;

	count = 0;

	for (int j = 0; j < SIZE; j++) {
		for (int k = 0; k < SIZE; k++) {
			scanf_s("%d", &_np[j][k]);
		}
	}

	__np = get_status();
	__pos = get_position();

	//printf("Initial state:\n");
	//view_puzzle();

	return (__np);
}

position get_position(void)
{
	int i, j;
	int flag = TRUE;
	position _pos;

	for (i = 0; i < SIZE && flag; i++)
	{
		for (j = 0; j < SIZE; j++)
		{
			if (_np[i][j] == BLANK)
			{
				_pos.row = i;
				_pos.col = j;

				flag = FALSE;
				break;
			}
		}
	}

	return (_pos);
}

void swap_position(int row, int col)
{
	int tmp;

	tmp = _np[__pos.row][__pos.col];
	_np[__pos.row][__pos.col] = _np[row][col];
	_np[row][col] = tmp;
	__pos.row = row;
	__pos.col = col;
}

status move(direction dir)
{
	int tmp;
	int i, j, endflag = TRUE;

	_trycount++;
	tmp = _np[__pos.row][__pos.col];

	switch (dir)
	{
	case UP:
		if (__pos.row == SIZE - 1) return (ERROR);
		swap_position(__pos.row + 1, __pos.col);
		s[count] = 'D'; count++;
		break;
	case DOWN:
		if (__pos.row == 0) return (ERROR);
		swap_position(__pos.row - 1, __pos.col);
		s[count] = 'U'; count++;
		break;
	case LEFT:
		if (__pos.col == SIZE - 1) return (ERROR);
		swap_position(__pos.row, __pos.col + 1);
		s[count] = 'R'; count++;
		break;
	case RIGHT:
		if (__pos.col == 0) return (ERROR);
		swap_position(__pos.row, __pos.col - 1);
		s[count] = 'L'; count++;
		break;
	}

	for (i = 0; i < SIZE && endflag; i++)
	{
		for (j = 0; j < SIZE; j++)
		{
			if (_np[i][j] != i * SIZE + j + 1)
			{
				endflag = FALSE;
				break;
			}
		}
	}



	if (endflag)
	{
		printf("\n#%d %d ", T + 1, _trycount);
		for (int i = 0; i < count; i++) {
			printf("%c ", s[i]);
		}
		printf("\n"); printf("\a");
	}

	return (SUCCESS);
}